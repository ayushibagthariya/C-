﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace condtional
{
    class Program
    {
        static void Main(string[] args)
        {
            //Result
            Console.Write("Enter mark 1:");
            int m1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter mark 2:");
            int m2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter mark 3:");
            int m3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter mark 4:");
            int m4 = Convert.ToInt32(Console.ReadLine());
            int total;
            float per = 0;
            string res="",grade ="";
            total = m1 + m2 + m3 + m4;
            if ((m1 <= 100 && m2 <= 100 && m3 <= 100 && m4 <= 100) && (m1 > 0 && m2 > 0 && m3 > 0 && m4 > 0))
            {
                if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40)
                {
                    res = "PASS";
                    per = total /4;
                    if (per >= 80)
                    {
                        grade = "A";
                    }
                    else if (per >= 70)
                    {
                        grade = "B";
                    }
                    else if (per >= 60)
                    {
                        grade = "C";
                    }
                    else if (per >= 50)
                    {
                        grade = "D";
                    }
                    else
                    {
                        grade = "E";
                    }
                }
                else
                {
                    res = "FAIL";
                    per = 0;
                    grade = "F";
                }
                Console.WriteLine("Total:" + total);
                Console.WriteLine("percentage:" + per);
                Console.WriteLine("result:" + res);
                Console.WriteLine("grade:" + grade);
            }
            else
            {
                Console.WriteLine("Enter marks betweeno to 100");
            }
            Console.Read();





        }
    }
}
