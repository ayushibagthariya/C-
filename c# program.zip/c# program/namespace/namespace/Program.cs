﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @namespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("write name:");
            string a = Console.ReadLine();
            Console.Write("write name");
            string b = Console.ReadLine();                                                               
            Console.Write(a);
            Console.Read();

 
        }
    }
}

